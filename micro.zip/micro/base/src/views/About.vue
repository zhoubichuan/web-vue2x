<template>
  <div class="about">
    <h1>这里是基座about页面，页面基于vue3.x开发</h1>
  </div>
</template>
